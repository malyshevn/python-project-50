### Hexlet tests and linter status:
[![Actions Status](https://github.com/malyshevn/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/malyshevn/python-project-50/actions)
<a href="https://codeclimate.com/github/malyshevn/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/89f1fbfb774e33d38001/maintainability" /></a>
<a href="https://codeclimate.com/github/malyshevn/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/89f1fbfb774e33d38001/test_coverage" /></a>

<a href="https://asciinema.org/a/7lu0zCMSbyqobMxt2MgZTUJwB" target="_blank"><img src="https://asciinema.org/a/7lu0zCMSbyqobMxt2MgZTUJwB.svg" /></a>
<a href="https://asciinema.org/a/rMHKlnjSj75P0NqXANtmZWwzW" target="_blank"><img src="https://asciinema.org/a/rMHKlnjSj75P0NqXANtmZWwzW.svg" /></a>