from gendiff.scripts.gendiff import generate_diff

__all__ = ("generate_diff")