import argparse
import json
import yaml
import os


def main():
    parser = argparse.ArgumentParser(
        description='Compares two configuration files and shows a difference.'
        )
    parser.add_argument('first_file')
    parser.add_argument('second_file')
    parser.add_argument('-f', '--format', help='set format of output')
    args = parser.parse_args()
    print(generate_diff(args.first_file, args.second_file))


def load_data(file_path):
    _, extension = os.path.splitext(file_path)
    extension = extension.lower()

    if extension == '.json':
        with open(file_path) as file:
            return json.load(file)
    elif extension == '.yaml':
        with open(file_path) as file:
            return yaml.load(file, Loader=yaml.Loader)
    else:
        raise ValueError(f'Unsupported file format: {extension}')



def generate_diff(file_path_1, file_path_2):
        data1 = load_data(file_path_1)
        data2 = load_data(file_path_2)

        keys = sorted(set(data1.keys()) | set(data2.keys()))
        diff = []

        for key in keys:
            if key in data1 and key in data2:
                if data1[key] == data2[key]:
                    diff.append(f"  {key}: {data1[key]}")
                else:
                    diff.append(f"- {key}: {data1[key]}")
                    diff.append(f"+ {key}: {data2[key]}")
            elif key in data1:
                diff.append(f"- {key}: {data1[key]}")
            else:
                diff.append(f"+ {key}: {data2[key]}")

        return diff


if __name__ == "__main__":
    main()
