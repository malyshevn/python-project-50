from hexlet_code.scripts.gendiff import generate_diff

__all__ = ("generate_diff")